// Lấy các phần tử HTML cần sử dụng
const scoreText = document.getElementById("score");
const timeText = document.getElementById("time");
const durationInput = document.getElementById("duration");
const startBtn = document.getElementById("startBtn");
const colorBtn = document.getElementById("colorBtn");
const playerBtn = document.getElementById("playerBtn");
const playerInfo = document.getElementById("playerInfo");
const arena = document.getElementById("arena");
const target = document.getElementById("target");
const result = document.getElementById("result");

// Khai báo biến lưu điểm, thời gian và trạng thái trò chơi
let score = 0;
let timeLeft = 30;
let timer = null;
let moveTimer = null;
let isPlaying = false;

// Mã sinh viên của người thực hiện bài tập
const studentId = "241A010634";

// Hàm đưa mục tiêu đến vị trí ngẫu nhiên trong khu vực chơi
function moveTarget() {
    const maxLeft = arena.clientWidth - target.offsetWidth;
    const maxTop = arena.clientHeight - target.offsetHeight;

    const left = Math.random() * maxLeft;
    const top = Math.random() * maxTop;

    target.style.left = left + "px";
    target.style.top = top + "px";
}

// Hàm bắt đầu trò chơi
function startGame() {
    // Xóa bộ đếm cũ để tránh chạy nhiều bộ đếm cùng lúc
    clearInterval(timer);
    clearInterval(moveTimer);

    // Lấy thời gian do người chơi nhập
    const selectedDuration = Number(durationInput.value);

    // Kiểm tra thời gian nhập vào có hợp lệ không
    if (!Number.isInteger(selectedDuration) ||
        selectedDuration < 5 || selectedDuration > 300) {
        alert("Vui lòng nhập thời gian từ 5 đến 300 giây.");
        durationInput.focus();
        return;
    }

    // Đặt lại điểm và thời gian cho lượt chơi mới
    score = 0;
    timeLeft = selectedDuration;
    isPlaying = true;

    scoreText.textContent = score;
    timeText.textContent = timeLeft;
    result.textContent = "";
    playerInfo.textContent = "";

    // Khóa nút bắt đầu và ô nhập trong lúc chơi
    startBtn.disabled = true;
    durationInput.disabled = true;
    colorBtn.disabled = false;

    // Hiện mục tiêu và di chuyển đến vị trí đầu tiên
    target.style.display = "block";
    moveTarget();

    // Tự động đổi vị trí mục tiêu sau mỗi giây
    moveTimer = setInterval(moveTarget, 1000);

    // Cập nhật thời gian còn lại mỗi giây
    timer = setInterval(function () {
        timeLeft--;
        timeText.textContent = timeLeft;

        // Kết thúc khi thời gian còn lại bằng 0
        if (timeLeft <= 0) {
            endGame();
        }
    }, 1000);
}

// Hàm xử lý khi người chơi bấm trúng mục tiêu
function hitTarget() {
    // Không cộng điểm nếu trò chơi đã kết thúc
    if (!isPlaying) {
        return;
    }

    // Tăng điểm lên 1 và cập nhật lên màn hình
    score++;
    scoreText.textContent = score;

    // Di chuyển mục tiêu ngay sau khi click trúng
    moveTarget();
}

// Hàm đổi màu nền khu vực chơi một cách ngẫu nhiên
function changeBackground() {
    const colors = [
        "#dbeafe", "#dcfce7", "#fce7f3",
        "#fef3c7", "#ede9fe", "#cffafe"
    ];

    const randomIndex = Math.floor(Math.random() * colors.length);
    arena.style.backgroundColor = colors[randomIndex];
}

// Hàm hiển thị mã sinh viên
function showPlayer() {
    playerInfo.textContent = "Mã sinh viên: " + studentId;
}

// Hàm kết thúc trò chơi
function endGame() {
    // Đổi trạng thái để không thể tiếp tục ghi điểm
    isPlaying = false;

    // Dừng cả bộ đếm thời gian và bộ đếm di chuyển mục tiêu
    clearInterval(timer);
    clearInterval(moveTimer);

    // Ẩn và khóa mục tiêu
    target.style.display = "none";
    target.disabled = true;

    // Khóa các thao tác trong lượt chơi đã kết thúc
    colorBtn.disabled = true;
    durationInput.disabled = true;

    // Cho phép bắt đầu lượt mới
    startBtn.disabled = false;
    startBtn.textContent = "Chơi lại";

    // Hiển thị tổng điểm đạt được
    result.textContent = "Hết giờ! Tổng điểm của bạn: " + score;
}

// Gắn các hàm vào sự kiện click của từng nút
startBtn.addEventListener("click", startGame);
target.addEventListener("click", hitTarget);
colorBtn.addEventListener("click", changeBackground);
playerBtn.addEventListener("click", showPlayer);

// Đảm bảo mục tiêu được mở khóa khi bắt đầu lượt chơi mới
startBtn.addEventListener("click", function () {
    if (isPlaying) {
        target.disabled = false;
    }
});
